class Evt{
    public type:string;
    public target;
    public method:string;
    public args;
}